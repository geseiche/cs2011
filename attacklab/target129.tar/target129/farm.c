/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_209()
{
    return 3351742792U;
}

unsigned getval_452()
{
    return 2428995912U;
}

void setval_177(unsigned *p)
{
    *p = 3281031256U;
}

unsigned addval_179(unsigned x)
{
    return x + 3281031240U;
}

void setval_451(unsigned *p)
{
    *p = 3284633928U;
}

void setval_326(unsigned *p)
{
    *p = 2462550344U;
}

unsigned addval_487(unsigned x)
{
    return x + 3281031248U;
}

void setval_367(unsigned *p)
{
    *p = 2421694470U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_401()
{
    return 3286272328U;
}

void setval_427(unsigned *p)
{
    *p = 3221804681U;
}

unsigned getval_299()
{
    return 3221799305U;
}

unsigned getval_428()
{
    return 3286272344U;
}

unsigned getval_431()
{
    return 3284240719U;
}

unsigned addval_463(unsigned x)
{
    return x + 3767093399U;
}

unsigned addval_234(unsigned x)
{
    return x + 3682910603U;
}

void setval_255(unsigned *p)
{
    *p = 3677929869U;
}

void setval_373(unsigned *p)
{
    *p = 2497743176U;
}

void setval_126(unsigned *p)
{
    *p = 4223910313U;
}

unsigned addval_192(unsigned x)
{
    return x + 264489673U;
}

void setval_453(unsigned *p)
{
    *p = 3375942313U;
}

void setval_180(unsigned *p)
{
    *p = 3468935433U;
}

void setval_319(unsigned *p)
{
    *p = 3269495112U;
}

unsigned addval_247(unsigned x)
{
    return x + 3281046157U;
}

void setval_205(unsigned *p)
{
    *p = 3232025225U;
}

unsigned addval_462(unsigned x)
{
    return x + 3223372041U;
}

unsigned getval_494()
{
    return 2425408009U;
}

unsigned getval_413()
{
    return 3224950409U;
}

unsigned getval_269()
{
    return 3285618090U;
}

void setval_232(unsigned *p)
{
    *p = 3375942281U;
}

void setval_351(unsigned *p)
{
    *p = 3373848201U;
}

void setval_330(unsigned *p)
{
    *p = 2463533333U;
}

unsigned addval_345(unsigned x)
{
    return x + 3524840073U;
}

void setval_201(unsigned *p)
{
    *p = 3286272344U;
}

void setval_130(unsigned *p)
{
    *p = 3398021933U;
}

unsigned getval_120()
{
    return 3252717896U;
}

unsigned addval_206(unsigned x)
{
    return x + 3229144713U;
}

unsigned getval_481()
{
    return 3676357065U;
}

void setval_357(unsigned *p)
{
    *p = 3524843145U;
}

unsigned getval_220()
{
    return 3353381192U;
}

unsigned addval_228(unsigned x)
{
    return x + 3677935245U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
